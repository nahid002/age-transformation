import util.util as util

if __name__ == "__main__":
    util.download_pretrained_models()
